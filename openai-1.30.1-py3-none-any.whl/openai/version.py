from ._version import __version__

VERSION: str = __version__
